Example file name:
Folder	- en/english_game_name.jpg
		- vi/english_game_name.jpg
		-zh/english_game_name.jpg

Types of Image Files: JPEG (or JPG), PNG, GIF 
 